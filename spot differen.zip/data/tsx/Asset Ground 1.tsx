<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.11.2" name="Asset Ground 1" tilewidth="64" tileheight="64" tilecount="4096" columns="64">
 <image source="../../../../Bahan/Asset Final/Asset Ground 1.png" width="4096" height="4096"/>
 <wangsets>
  <wangset name="Ground" type="corner" tile="-1"/>
 </wangsets>
</tileset>
