<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.11.2" name="Object Bangunan" tilewidth="144" tileheight="152" tilecount="5" columns="0">
 <grid orientation="orthogonal" width="1" height="1"/>
 <tile id="0">
  <image source="../../../Bahan/Asset Final/Layer 19.png" width="144" height="152"/>
 </tile>
 <tile id="1">
  <image source="../../../Bahan/Asset Final/Layer 15.png" width="47" height="46"/>
 </tile>
 <tile id="2">
  <image source="../../../Bahan/Asset Final/Layer 16.png" width="64" height="63"/>
 </tile>
 <tile id="3">
  <image source="../../../Bahan/Asset Final/Layer 17.png" width="92" height="83"/>
 </tile>
 <tile id="4">
  <image source="../../../Bahan/Asset Final/Layer 18.png" width="94" height="101"/>
 </tile>
</tileset>
