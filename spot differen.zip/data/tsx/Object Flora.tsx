<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.11.2" name="Object" tilewidth="221" tileheight="225" tilecount="28" columns="0">
 <grid orientation="orthogonal" width="1" height="1"/>
 <tile id="0">
  <image source="../../img/Layer 8.png" width="40" height="42"/>
 </tile>
 <tile id="1">
  <image source="../../img/Layer 9.png" width="42" height="38"/>
 </tile>
 <tile id="2">
  <image source="../../img/Layer 10.png" width="37" height="43"/>
 </tile>
 <tile id="3">
  <image source="../../img/Layer 11.png" width="40" height="40"/>
 </tile>
 <tile id="4">
  <image source="../../img/Layer 12.png" width="45" height="48"/>
 </tile>
 <tile id="5">
  <image source="../../img/Layer 13.png" width="71" height="67"/>
 </tile>
 <tile id="6">
  <image source="../../img/Layer 14.png" width="84" height="86"/>
 </tile>
 <tile id="7">
  <image source="../../img/Layer 20.png" width="24" height="22"/>
 </tile>
 <tile id="8">
  <image source="../../img/Layer 21.png" width="41" height="42"/>
 </tile>
 <tile id="9">
  <image source="../../img/Layer 22.png" width="69" height="55"/>
 </tile>
 <tile id="10">
  <image source="../../img/Pagar Labirin 1.png" width="127" height="165"/>
 </tile>
 <tile id="11">
  <image source="../../img/Pagar Labirin 2.png" width="60" height="225"/>
 </tile>
 <tile id="12">
  <image source="../../img/Pagar Labirin 3.png" width="127" height="165"/>
 </tile>
 <tile id="13">
  <image source="../../img/Pagar Labirin 4.png" width="118" height="176"/>
 </tile>
 <tile id="14">
  <image source="../../img/Pagar Labirin 5.png" width="118" height="176"/>
 </tile>
 <tile id="15">
  <image source="../../img/Pagar Labirin 6.png" width="221" height="109"/>
 </tile>
 <tile id="16">
  <image source="../../img/Asset 1.png" width="88" height="114"/>
 </tile>
 <tile id="17">
  <image source="../../img/Asset 2.png" width="77" height="97"/>
 </tile>
 <tile id="18">
  <image source="../../img/Asset 3.png" width="57" height="69"/>
 </tile>
 <tile id="19">
  <image source="../../img/Asset 4.png" width="46" height="46"/>
 </tile>
 <tile id="20">
  <image source="../../img/Asset 5.png" width="34" height="34"/>
 </tile>
 <tile id="21">
  <image source="../../img/Asset 6.png" width="22" height="21"/>
 </tile>
 <tile id="22">
  <image source="../../img/Layer 7.png" width="25" height="26"/>
 </tile>
 <tile id="23">
  <image source="../../img/Layer 19.png" width="144" height="152"/>
 </tile>
 <tile id="24">
  <image source="../../img/Layer 15.png" width="47" height="46"/>
 </tile>
 <tile id="25">
  <image source="../../img/Layer 16.png" width="64" height="63"/>
 </tile>
 <tile id="26">
  <image source="../../img/Layer 17.png" width="92" height="83"/>
 </tile>
 <tile id="27">
  <image source="../../img/Layer 18.png" width="94" height="101"/>
 </tile>
</tileset>
