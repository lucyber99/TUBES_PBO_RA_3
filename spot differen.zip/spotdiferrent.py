
import pygame
import sys

pygame.init()
WIDTH, HEIGHT = 1920, 1080
screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("Spot The Difference")
font = pygame.font.SysFont(None, 32)

# Colors
WHITE = (255, 255, 255)
BLACK = (0, 0, 0)
BLUE = (40, 120, 255)
RED = (220, 0, 0)
GREEN = (0, 160, 0)

# Load image
left_img = pygame.image.load("data\images\entities\Spot_difer.png").convert_alpha()
right_img = pygame.image.load("data\images\entities\spot_difer2.png").convert_alpha()
circle_img = pygame.image.load("data\images\entities\Red_Circle.png").convert_alpha()
circle_img = pygame.transform.scale(circle_img, (70,70))  # Ukuran penanda


# Posisi gambar
left_pos = (50, 100)
right_pos = (720, 100)

# Area perbedaan relatif terhadap gambar kiri
differences = [

    pygame.Rect(290, 400, 100,100),#posisi batu
    pygame.Rect(1, 340, 100,100),#posisi batu kiri
    pygame.Rect(290, 25, 100,100),#posisi awan
    pygame.Rect(130, 250, 100,100),#posisi pohon
    pygame.Rect(130, 480, 100,100),#posisi ekor rubah
    pygame.Rect(175, 520, 100,100),#posisi rubah
]
found = []
max_guesses = 3
max_hints = 3
guesses_used = 0
hints_used = 0
show_hint = False
game_over = False
ask_retry = False

def draw_text(text, pos, color=BLACK):
    img = font.render(text, True, color)
    screen.blit(img, pos)

def check_click(pos):
    global guesses_used
    correct = False
    for rect in differences:
        if rect in found:
            continue
        if rect.move(left_pos).collidepoint(pos) or rect.move(right_pos).collidepoint(pos):
            print(True)
            found.append(rect)
            correct = True
            break

    if not correct:
        print(False)
        guesses_used += 1


def reset_game():
    global guesses_used, found, game_over, ask_retry
    guesses_used = 0
    found = []
    game_over = False
    ask_retry = False

running = True
while running:
    screen.fill(WHITE)

    # --- UI Atas: Level, Score, Nyawa ---
    draw_text("Level 1", (30, 30))
    draw_text(f"{len(found)}/{len(differences)}", (650, 30), GREEN)
    draw_text(f"❤️ {max_guesses - guesses_used}", (750, 30), RED)

    # --- Gambar Kiri dan Kanan ---
    screen.blit(left_img, left_pos)
    screen.blit(right_img, right_pos)

    # --- Tampilkan perbedaan yang ditemukan ---
    for rect in found:
        screen.blit(circle_img, (left_pos[0] + rect.x, left_pos[1] + rect.y))
        screen.blit(circle_img, (right_pos[0] + rect.x, right_pos[1] + rect.y))

    # --- Hint visual ---
    if show_hint and hints_used < max_hints:
        for rect in differences:
            if rect not in found:
                pygame.draw.rect(screen, RED, rect.move(right_pos), 3)
                show_hint = False
                hints_used += 1
                break

    # --- Tombol Hint ---
    hint_button = pygame.Rect(WIDTH//2 - 100, 620, 200, 50)
    pygame.draw.rect(screen, BLUE, hint_button, border_radius=10)
    draw_text("Get a hint ▶", (WIDTH//2 - 70, 635), WHITE)

    # --- Game Over / Menang ---
    if len(found) == len(differences):
        draw_text("🎉 Kamu Menang!", (550, 560), GREEN)
        game_over = True

    elif guesses_used >= max_guesses and len(found) < len(differences):
        draw_text("💥 Game Over", (580, 560), RED)
        draw_text("Coba lagi? (Y = Ya / N = Tidak)", (470, 600))
        game_over = True
        ask_retry = True

    # --- Event Handling ---
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False

        elif not game_over:
            if event.type == pygame.MOUSEBUTTONDOWN:
                if hint_button.collidepoint(event.pos):
                    show_hint = True
                else:
                    check_click(event.pos)

            elif event.type == pygame.KEYDOWN and event.key == pygame.K_h:
                show_hint = True

        elif ask_retry and event.type == pygame.KEYDOWN:
            if event.key == pygame.K_y:
                reset_game()
            elif event.key == pygame.K_n:
                running = False

    pygame.display.flip()
    pygame.time.Clock().tick(60)

pygame.quit()
sys.exit()
